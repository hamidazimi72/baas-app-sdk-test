'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';

import { AnalyticsSdk, AuthSdk, CoreSdk, PushSdk } from 'baas-web-sdk';

import { MBAAS_CONFIG_CHANGED_EVENT, readMbaasConfig } from './mbaas-config-storage';
import { installMbaasFetchProxy } from './mbaas-fetch-proxy';

type MbaasSdkContextValue = {
	core: CoreSdk | null;
	auth: AuthSdk | null;
	push: PushSdk | null;
	analytics: AnalyticsSdk | null;
	isConfigured: boolean;
	isInitialized: boolean;
	isPushInitialized: boolean;
	isAnalyticsInitialized: boolean;
	initializationError: Error | null;
	pushInitializationError: Error | null;
};

const MbaasSdkContext = createContext<MbaasSdkContextValue | null>(null);

const getCoreConfig = () => readMbaasConfig();

type CoreConfig = ReturnType<typeof getCoreConfig>;

const isSameCoreConfig = (current: CoreConfig | null, next: CoreConfig) => current?.apiKey === next.apiKey;

export function MbaasProvider({ children }: Readonly<{ children: React.ReactNode }>) {
	const [config, setConfig] = useState<CoreConfig | null>(null);
	const [isInitialized, setIsInitialized] = useState(false);
	const [initializationError, setInitializationError] = useState<Error | null>(null);
	const [isPushInitialized, setIsPushInitialized] = useState(false);
	const [analytics, setAnalytics] = useState<AnalyticsSdk | null>(null);
	const [isAnalyticsInitialized, setIsAnalyticsInitialized] = useState(false);
	const [pushInitializationError, setPushInitializationError] = useState<Error | null>(null);

	useEffect(() => {
		const syncStoredConfig = () => {
			const nextConfig = getCoreConfig();
			setConfig((currentConfig) => (isSameCoreConfig(currentConfig, nextConfig) ? currentConfig : nextConfig));
		};
		syncStoredConfig();
		window.addEventListener(MBAAS_CONFIG_CHANGED_EVENT, syncStoredConfig);

		return () => window.removeEventListener(MBAAS_CONFIG_CHANGED_EVENT, syncStoredConfig);
	}, []);

	const core = useMemo(() => {
		if (!config?.apiKey) return null;
		installMbaasFetchProxy();
		return new CoreSdk(config);
	}, [config]);

	const auth = useMemo(() => (core ? new AuthSdk(core) : null), [core]);
	const push = useMemo(() => (core ? new PushSdk(core) : null), [core]);

	useEffect(() => {
		if (!core || !isInitialized || typeof window === 'undefined') return;

		const analyticsSdk = new AnalyticsSdk(core, { appVersion: '3.2.1' });
		setAnalytics(analyticsSdk);
		setIsAnalyticsInitialized(true);

		return () => {
			analyticsSdk.destroy();
			setAnalytics(null);
			setIsAnalyticsInitialized(false);
		};
	}, [core, isInitialized]);

	useEffect(() => {
		if (!core) return;

		let active = true;
		setIsInitialized(false);
		setInitializationError(null);
		void core
			.initializeApp()
			.then(() => {
				if (active) setIsInitialized(true);
			})
			.catch((error: unknown) => {
				if (!active) return;
				setInitializationError(error instanceof Error ? error : new Error(String(error)));
			});

		return () => {
			active = false;
		};
	}, [core]);

	useEffect(() => {
		if (!core || !push || !isInitialized || typeof window === 'undefined' || !('serviceWorker' in navigator)) return;

		let active = true;
		setIsPushInitialized(false);
		setPushInitializationError(null);
		const initializePush = async () => {
			try {
				const registration = await navigator.serviceWorker.register('/sw.js');
				if (!registration) return;
				await push.start();
				if (active) setIsPushInitialized(true);
			} catch (error: unknown) {
				if (!active) return;
				setPushInitializationError(error instanceof Error ? error : new Error(String(error)));
			}
		};

		if (document.readyState === 'complete') void initializePush();
		else window.addEventListener('load', initializePush, { once: true });

		return () => {
			active = false;
			window.removeEventListener('load', initializePush);
			push.disconnect();
		};
	}, [core, isInitialized, push]);

	const value = useMemo<MbaasSdkContextValue>(
		() => ({
			core,
			auth,
			push,
			analytics,
			isConfigured: Boolean(core && auth),
			isInitialized,
			isPushInitialized,
			isAnalyticsInitialized,
			initializationError,
			pushInitializationError,
		}),
		[
			analytics,
			auth,
			core,
			initializationError,
			isAnalyticsInitialized,
			isInitialized,
			isPushInitialized,
			push,
			pushInitializationError,
		],
	);

	return <MbaasSdkContext.Provider value={value}>{children}</MbaasSdkContext.Provider>;
}

export function useMbaasSdk(): MbaasSdkContextValue {
	const context = useContext(MbaasSdkContext);
	if (!context) throw new Error('useMbaasSdk must be used inside MbaasProvider.');
	return context;
}

export function useMbaasCore(): CoreSdk {
	const { core } = useMbaasSdk();
	if (!core) throw new Error('Mbaas CoreSdk is not configured. Check .env.local.');
	return core;
}

export function useMbaasAuth(): AuthSdk {
	const { auth } = useMbaasSdk();
	if (!auth) throw new Error('Mbaas AuthSdk is not configured. Check .env.local.');
	return auth;
}

export function useMbaasPush(): PushSdk {
	const { push } = useMbaasSdk();
	if (!push) throw new Error('Mbaas PushSdk is not configured. Check .env.local.');
	return push;
}

export function useMbaasAnalytics(): AnalyticsSdk {
	const { analytics } = useMbaasSdk();
	if (!analytics) throw new Error('Mbaas AnalyticsSdk is not initialized yet.');
	return analytics;
}
