!(function () {
	'use strict';
	!(function () {
		const t = 'GapPushSDK';
		self[t] || (self[t] = {});
		const n = self[t];
		n.version = '1.0.14';
		const o = 'installation-tokens';
		((n.reportNotificationEvent = async function (t, n) {
			try {
				const e = await new Promise((t, n) => {
						const e = indexedDB.open('mbaas-sdk', 2);
						((e.onupgradeneeded = () => {
							e.result.objectStoreNames.contains(o) || e.result.createObjectStore(o);
						}),
							(e.onsuccess = () => {
								const i = e.result,
									a = i.transaction(o, 'readonly').objectStore(o).get('mbaas:installation_token');
								((a.onsuccess = () => {
									(i.close(), t(a.result || null));
								}),
									(a.onerror = () => {
										(i.close(), n(a.error));
									}));
							}),
							(e.onerror = () => n(e.error)));
					}),
					i = { 'Content-Type': 'application/json' };
				e && (i.Authorization = `Bearer ${e}`);
				return await fetch('https://push-gateway-stage.baas.gov.ir/api/v1/push/event', {
					method: 'POST',
					headers: i,
					keepalive: !0,
					body: JSON.stringify({ eventType: t, pushId: n.notification.data?.pushId }),
				});
			} catch (t) {
				throw t;
			}
		}),
			(n.handleNotificationClick = function (t) {
				const o = t.notification.data?.url || new URL(self.location.origin).href;
				t.waitUntil(
					(async () => {
						try {
							await n.reportNotificationEvent('OPENED', t);
						} catch (t) {
							console.error('Failed to report click:', t);
						}
						try {
							const t = await clients.matchAll({ type: 'window', includeUncontrolled: !0 });
							for (const n of t) if (n.url === o && 'focus' in n) return await n.focus();
							if (clients.openWindow) return await clients.openWindow(o);
						} catch (t) {
							console.error('Failed to open window:', t);
						}
					})(),
				);
			}),
			(n.handleNotificationClose = function (t) {
				t.waitUntil(Promise.all([n.reportNotificationEvent('DISMISSED', t)]));
			}),
			self.addEventListener('notificationclick', function (t) {
				n.handleNotificationClick(t);
			}),
			self.addEventListener('notificationclose', function (t) {
				n.handleNotificationClose(t);
			}));
	})();
})();
