/** @type {import('next').NextConfig} */

// const isProd = process.env.NODE_ENV === 'production';

const securityHeaders = [
	{ key: 'X-Content-Type-Options', value: 'nosniff' },
	{ key: 'X-Frame-Options', value: 'DENY' },
	{ key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
	{ key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), browsing-topics=()' },
	{ key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
	{ key: 'Cross-Origin-Resource-Policy', value: 'same-origin' },
	{ key: 'X-DNS-Prefetch-Control', value: 'off' },
];

const nextConfig = {
	reactStrictMode: false,
	poweredByHeader: false,
	compiler: {
		removeConsole: false,
		// removeConsole: isProd ? { exclude: ['error'] } : false,
	},
	output: 'standalone',
	async headers() {
		return [{ source: '/:path*', headers: securityHeaders }];
	},
};

export default nextConfig;
